import Doctor from '../models/doctor.js';

const cdoctores = (req, res)=> {
    res.send("vista")
}
const crearDoctor = async (req, res) => {
    try {
        const {nombre, password, email, celular,token, confirmado}=req.body;
        const nuevoDoctor = new Doctor({
            nombre,
            password,
            email,
            celular,
            token,
            confirmado
        });
        const saveddoc = await nuevoDoctor.save();
        res.status(201).json({mensaje:"Doctor registrado exitosamente", doctor: saveddoc});

    } catch (error){
        console.error("Error al crear el doctor",error);
        res.status(500).json({error:"error al crear el doctor"});
    }
};

export{
    cdoctores, crearDoctor
};