import express from 'express';
import { crearDoctor } from '../control/control.js';

const router = express.Router();

// router.get("/", (req, res)=>{
//     res.send("vista para docotores")
// });

router.post("/register",crearDoctor);

export default router;
